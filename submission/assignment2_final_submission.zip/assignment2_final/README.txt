assignment2_final - EE6161 Assignment 2

CONTENTS
  CMakeLists.txt             Qt Creator / CMake project
  src/                      C++ and Qt Widgets source files
  CLASS_DESIGN_REPORT.txt    Class design report
  README.txt                Build and operation instructions

BUILD AND RUN
  Requires a C++17 compiler and Qt Widgets (tested with Qt 6.11.2 on macOS).
  1. In Qt Creator choose File > Open File or Project.
  2. Open CMakeLists.txt and select a matching Desktop Qt kit.
  3. Configure and build the project.
  4. Select assignment2_final as the run target and press Run.

  Command-line alternative (with CMake and a build tool installed):
    cmake -S . -B build -DCMAKE_PREFIX_PATH=<Qt-kit-directory>
    cmake --build build

  game_core is the library, not the application to run.
  No testing framework, Doxygen or Graphviz is needed to build this package.
  Windows Qt Creator compilation still needs to be verified on Windows.

PLAY
  Set Width, Height and Race, then press New game.
  Use the buttons, or enter a command and press Enter / Send:
    n / s / e / w   Move north / south / east / west
    p               Pick up the current item
    d               Choose an item to drop
    a               Attack the current enemy
    l               Look at the current location
    i               Display inventory and gold
    x or exit       End the game and display the score

  Commands are case-insensitive. East uses e; exit uses x or full exit.
  Every submitted command advances time, even if unsuccessful. Each day/night
  phase lasts five commands. Defeated enemies award gold equal to their
  effective defence. Health at or below zero ends the game.
  The class design report explains rules chosen for ambiguous cases.
