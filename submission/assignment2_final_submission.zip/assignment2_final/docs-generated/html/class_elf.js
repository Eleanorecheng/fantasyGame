var class_elf =
[
    [ "Elf", "class_elf.html#a0f63e3a9745d2d7c3ad5010e80719a64", null ],
    [ "defendedDamage", "class_elf.html#a2600480388aeaf0d18b504b1d427b41c", null ]
];