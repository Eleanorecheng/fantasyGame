var annotated_dup =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "Character", "class_character.html", "class_character" ],
    [ "Dwarf", "class_dwarf.html", "class_dwarf" ],
    [ "Elf", "class_elf.html", "class_elf" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "Hobbit", "class_hobbit.html", "class_hobbit" ],
    [ "Human", "class_human.html", "class_human" ],
    [ "Item", "class_item.html", "class_item" ],
    [ "Orc", "class_orc.html", "class_orc" ],
    [ "Square", "class_square.html", "class_square" ],
    [ "Stats", "class_stats.html", "class_stats" ],
    [ "Window", "class_window.html", "class_window" ]
];