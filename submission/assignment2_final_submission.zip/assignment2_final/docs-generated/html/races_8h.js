var races_8h =
[
    [ "Human", "class_human.html", "class_human" ],
    [ "Elf", "class_elf.html", "class_elf" ],
    [ "Dwarf", "class_dwarf.html", "class_dwarf" ],
    [ "Hobbit", "class_hobbit.html", "class_hobbit" ],
    [ "Orc", "class_orc.html", "class_orc" ],
    [ "makeCharacter", "races_8h.html#a6f6ba0ca28942463fd4e4d80192a5dd0", null ]
];