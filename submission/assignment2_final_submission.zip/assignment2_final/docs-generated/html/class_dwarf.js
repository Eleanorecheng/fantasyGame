var class_dwarf =
[
    [ "Dwarf", "class_dwarf.html#a222f5e5ff5094c68a1cd6124a0272154", null ],
    [ "defendedDamage", "class_dwarf.html#ace309e1e3db078015fce2940f6c58027", null ]
];