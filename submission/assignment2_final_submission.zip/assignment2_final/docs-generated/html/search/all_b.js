var searchData=
[
  ['name_0',['name',['../class_item.html#a342b7a351c9ae1c5430aa3ef65b670bd',1,'Item']]],
  ['navigation_20notes_1',['Navigation notes',['../index.html#autotoc_md6',1,'']]],
  ['night_2',['night',['../class_game.html#a5d37c926c1b0bb226d6e5c0097f682af',1,'Game']]],
  ['notes_3',['Navigation notes',['../index.html#autotoc_md6',1,'']]]
];
