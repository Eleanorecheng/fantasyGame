var searchData=
[
  ['character_20inheritance_0',['Character inheritance',['../index.html#autotoc_md4',1,'']]],
  ['command_1',['Follow an attack command',['../index.html#autotoc_md5',1,'']]]
];
