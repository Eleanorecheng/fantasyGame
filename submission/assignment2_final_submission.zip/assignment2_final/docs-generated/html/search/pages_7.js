var searchData=
[
  ['object_20ownership_0',['Object ownership',['../index.html#autotoc_md3',1,'']]],
  ['ownership_1',['Object ownership',['../index.html#autotoc_md3',1,'']]]
];
