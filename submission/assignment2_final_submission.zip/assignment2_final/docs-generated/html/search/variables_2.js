var searchData=
[
  ['defence_0',['defence',['../class_item.html#a5a179101c47805487da8da847f0e8cf9',1,'Item::defence'],['../class_stats.html#a5c5c1fc0be51c6bdf01ef29615fef90c',1,'Stats::defence']]],
  ['defencechance_1',['defenceChance',['../class_stats.html#aeb1c2290ce880f1400ec9936957b4c27',1,'Stats']]]
];
