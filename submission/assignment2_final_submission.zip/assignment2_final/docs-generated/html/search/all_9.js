var searchData=
[
  ['look_0',['look',['../class_game.html#a29c897fdb95c6cb34ba6731ee4d86c54',1,'Game']]]
];
