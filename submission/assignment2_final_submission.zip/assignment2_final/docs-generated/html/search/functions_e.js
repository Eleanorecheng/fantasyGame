var searchData=
[
  ['turns_0',['turns',['../class_game.html#a10033cc2581b1d38ac167519d296bdba',1,'Game']]]
];
