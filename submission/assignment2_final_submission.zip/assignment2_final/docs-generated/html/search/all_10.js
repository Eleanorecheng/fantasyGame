var searchData=
[
  ['to_20start_0',['Where to start',['../index.html#autotoc_md1',1,'']]],
  ['turns_1',['turns',['../class_game.html#a10033cc2581b1d38ac167519d296bdba',1,'Game']]]
];
