var searchData=
[
  ['damage_0',['damage',['../class_character.html#ac827bcc43e20facb142a65d5ed201db9',1,'Character']]],
  ['dead_1',['dead',['../class_character.html#ace88f805aa4b51d39ba5fb2b7a6573be',1,'Character']]],
  ['defence_2',['defence',['../class_item.html#a5a179101c47805487da8da847f0e8cf9',1,'Item::defence'],['../class_stats.html#a5c5c1fc0be51c6bdf01ef29615fef90c',1,'Stats::defence']]],
  ['defencechance_3',['defenceChance',['../class_stats.html#aeb1c2290ce880f1400ec9936957b4c27',1,'Stats']]],
  ['defendeddamage_4',['defendedDamage',['../class_character.html#ab2e75b9974729ca4e913c9454fd585a3',1,'Character::defendedDamage()'],['../class_human.html#a614c84e86708b391eb68929d33ca86e0',1,'Human::defendedDamage()'],['../class_elf.html#a2600480388aeaf0d18b504b1d427b41c',1,'Elf::defendedDamage()'],['../class_dwarf.html#ace309e1e3db078015fce2940f6c58027',1,'Dwarf::defendedDamage()'],['../class_hobbit.html#a3b9763dc0a0429d9125517c2247bc91c',1,'Hobbit::defendedDamage()'],['../class_orc.html#a96b137e6ed60d2bee014e7280478a252',1,'Orc::defendedDamage()']]],
  ['documentation_5',['assignment2_final API documentation',['../index.html',1,'']]],
  ['drop_6',['drop',['../class_character.html#a2c159e4d88762eb169b077ef2bbcc648',1,'Character']]],
  ['dropitem_7',['dropItem',['../class_game.html#a8fe2aef7f49bb5705d2c636bd793d6ef',1,'Game']]],
  ['dwarf_8',['Dwarf',['../class_dwarf.html',1,'Dwarf'],['../class_dwarf.html#a222f5e5ff5094c68a1cd6124a0272154',1,'Dwarf::Dwarf()']]]
];
