var searchData=
[
  ['square_0',['Square',['../class_square.html',1,'']]],
  ['stats_1',['Stats',['../class_stats.html',1,'']]]
];
