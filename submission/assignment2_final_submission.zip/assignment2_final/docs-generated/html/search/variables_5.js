var searchData=
[
  ['item_0',['item',['../class_square.html#aab2600cf64ec4e9ff1b48570fc3c8b6a',1,'Square']]]
];
