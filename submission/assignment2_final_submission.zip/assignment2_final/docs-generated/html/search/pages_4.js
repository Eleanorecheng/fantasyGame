var searchData=
[
  ['inheritance_0',['Character inheritance',['../index.html#autotoc_md4',1,'']]]
];
