var searchData=
[
  ['start_0',['Where to start',['../index.html#autotoc_md1',1,'']]]
];
