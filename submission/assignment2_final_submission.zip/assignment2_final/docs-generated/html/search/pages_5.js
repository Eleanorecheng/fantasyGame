var searchData=
[
  ['module_20responsibilities_0',['Module responsibilities',['../index.html#autotoc_md2',1,'']]]
];
