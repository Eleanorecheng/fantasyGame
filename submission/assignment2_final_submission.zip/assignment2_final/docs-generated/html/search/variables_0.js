var searchData=
[
  ['attack_0',['attack',['../class_item.html#a799f7094e1151b0574172aa146ed7512',1,'Item::attack'],['../class_stats.html#a4193a9eed69c91a03ca37ac1f73d4181',1,'Stats::attack']]],
  ['attackchance_1',['attackChance',['../class_stats.html#a86510e547e4e0d2c87d7e7297b99c028',1,'Stats']]]
];
