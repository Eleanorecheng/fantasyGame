var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstwxy~",
  1: "bcdeghiosw",
  2: "bcgimrsw",
  3: "acdeghilmnoprstwxy~",
  4: "acdehinsw",
  5: "cr",
  6: "acdfimnorstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Pages"
};

