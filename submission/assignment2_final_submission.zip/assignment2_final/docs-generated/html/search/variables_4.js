var searchData=
[
  ['health_0',['health',['../class_item.html#a5284e3576bb462edb43f94b030e5bdc6',1,'Item::health'],['../class_stats.html#a26301ce8db5c4a08e973234c5595fc4e',1,'Stats::health']]]
];
