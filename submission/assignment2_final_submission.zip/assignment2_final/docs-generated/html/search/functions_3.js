var searchData=
[
  ['elf_0',['Elf',['../class_elf.html#a0f63e3a9745d2d7c3ad5010e80719a64',1,'Elf']]],
  ['ended_1',['ended',['../class_game.html#af7027f6e17fb58f41e1889be388a4955',1,'Game']]]
];
