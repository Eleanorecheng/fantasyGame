var searchData=
[
  ['category_0',['category',['../class_item.html#a10226322349dff9e62a1b206cd0e672c',1,'Item']]]
];
