var searchData=
[
  ['strength_0',['strength',['../class_item.html#a6a41e330454a805923d12a1b85b79952',1,'Item::strength'],['../class_stats.html#aeeebf306c2233d7526a355de47f016ef',1,'Stats::strength']]]
];
