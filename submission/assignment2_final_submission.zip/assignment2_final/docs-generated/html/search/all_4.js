var searchData=
[
  ['elf_0',['Elf',['../class_elf.html',1,'Elf'],['../class_elf.html#a0f63e3a9745d2d7c3ad5010e80719a64',1,'Elf::Elf()']]],
  ['ended_1',['ended',['../class_game.html#af7027f6e17fb58f41e1889be388a4955',1,'Game']]],
  ['enemy_2',['enemy',['../class_square.html#af2c80a29da6011cc3f5ebd76b460ec5d',1,'Square']]]
];
