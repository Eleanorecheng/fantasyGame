var searchData=
[
  ['height_0',['height',['../class_board.html#a4a8acb1b2b63874e689b8a6feed5fe67',1,'Board::height()'],['../class_game.html#a6e2176b27be2ebd7aa4732de8a369d4b',1,'Game::height()']]],
  ['hobbit_1',['Hobbit',['../class_hobbit.html#a95c4e0717e0ae80aa445bd41d53e5eb9',1,'Hobbit']]],
  ['human_2',['Human',['../class_human.html#a4f84fcddcedd434023a001eba00a095c',1,'Human']]]
];
