var hierarchy =
[
    [ "Board", "class_board.html", null ],
    [ "Character", "class_character.html", [
      [ "Dwarf", "class_dwarf.html", null ],
      [ "Elf", "class_elf.html", null ],
      [ "Hobbit", "class_hobbit.html", null ],
      [ "Human", "class_human.html", null ],
      [ "Orc", "class_orc.html", null ]
    ] ],
    [ "Game", "class_game.html", null ],
    [ "Item", "class_item.html", null ],
    [ "QWidget", null, [
      [ "Window", "class_window.html", null ]
    ] ],
    [ "Square", "class_square.html", null ],
    [ "Stats", "class_stats.html", null ]
];