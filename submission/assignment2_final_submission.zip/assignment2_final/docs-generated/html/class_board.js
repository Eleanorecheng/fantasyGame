var class_board =
[
    [ "at", "class_board.html#a50a627e9ebd4394f2166016ac603ff08", null ],
    [ "at", "class_board.html#a5c7816b7194db73021d306871afd064e", null ],
    [ "height", "class_board.html#a4a8acb1b2b63874e689b8a6feed5fe67", null ],
    [ "reset", "class_board.html#a95bb9bbea525ee9f296382c051fbb51c", null ],
    [ "width", "class_board.html#af0153a4798752289e7fdfe04c149d61d", null ]
];