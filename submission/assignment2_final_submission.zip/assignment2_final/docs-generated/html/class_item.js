var class_item =
[
    [ "Item", "class_item.html#a297720c02984eab37332ae795d22189d", null ],
    [ "Item", "class_item.html#af5fcfbe2274e2b250ab88ebd822e9fc4", null ],
    [ "attack", "class_item.html#a799f7094e1151b0574172aa146ed7512", null ],
    [ "category", "class_item.html#a10226322349dff9e62a1b206cd0e672c", null ],
    [ "defence", "class_item.html#a5a179101c47805487da8da847f0e8cf9", null ],
    [ "health", "class_item.html#a5284e3576bb462edb43f94b030e5bdc6", null ],
    [ "name", "class_item.html#a342b7a351c9ae1c5430aa3ef65b670bd", null ],
    [ "strength", "class_item.html#a6a41e330454a805923d12a1b85b79952", null ],
    [ "weight", "class_item.html#a05e743552459fc8c2abdc80a0f4f0b0a", null ]
];