var class_stats =
[
    [ "Stats", "class_stats.html#a725b1282cef513cf4ab79662f26c5b94", null ],
    [ "attack", "class_stats.html#a4193a9eed69c91a03ca37ac1f73d4181", null ],
    [ "attackChance", "class_stats.html#a86510e547e4e0d2c87d7e7297b99c028", null ],
    [ "defence", "class_stats.html#a5c5c1fc0be51c6bdf01ef29615fef90c", null ],
    [ "defenceChance", "class_stats.html#aeb1c2290ce880f1400ec9936957b4c27", null ],
    [ "health", "class_stats.html#a26301ce8db5c4a08e973234c5595fc4e", null ],
    [ "strength", "class_stats.html#aeeebf306c2233d7526a355de47f016ef", null ]
];