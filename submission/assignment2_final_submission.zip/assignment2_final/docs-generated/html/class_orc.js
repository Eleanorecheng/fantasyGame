var class_orc =
[
    [ "Orc", "class_orc.html#ae52a4b77344fbca3fe2797f90bfb8de2", null ],
    [ "defendedDamage", "class_orc.html#a96b137e6ed60d2bee014e7280478a252", null ]
];