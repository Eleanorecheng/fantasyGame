var class_hobbit =
[
    [ "Hobbit", "class_hobbit.html#a95c4e0717e0ae80aa445bd41d53e5eb9", null ],
    [ "defendedDamage", "class_hobbit.html#a3b9763dc0a0429d9125517c2247bc91c", null ]
];