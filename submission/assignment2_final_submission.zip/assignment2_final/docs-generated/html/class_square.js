var class_square =
[
    [ "enemy", "class_square.html#af2c80a29da6011cc3f5ebd76b460ec5d", null ],
    [ "item", "class_square.html#aab2600cf64ec4e9ff1b48570fc3c8b6a", null ]
];