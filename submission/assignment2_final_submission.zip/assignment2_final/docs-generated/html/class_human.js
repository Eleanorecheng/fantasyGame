var class_human =
[
    [ "Human", "class_human.html#a4f84fcddcedd434023a001eba00a095c", null ],
    [ "defendedDamage", "class_human.html#a614c84e86708b391eb68929d33ca86e0", null ]
];