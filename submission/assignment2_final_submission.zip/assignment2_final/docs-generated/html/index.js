var index =
[
    [ "Where to start", "index.html#autotoc_md1", null ],
    [ "Module responsibilities", "index.html#autotoc_md2", null ],
    [ "Object ownership", "index.html#autotoc_md3", null ],
    [ "Character inheritance", "index.html#autotoc_md4", null ],
    [ "Follow an attack command", "index.html#autotoc_md5", null ],
    [ "Navigation notes", "index.html#autotoc_md6", null ]
];